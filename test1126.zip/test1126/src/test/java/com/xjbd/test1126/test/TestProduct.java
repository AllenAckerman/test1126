package com.xjbd.test1126.test;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.xjbd.test1126.entity.Product;
import com.xjbd.test1126.entity.Warehouse;

//测试类
public class TestProduct {

	
			//改变测试方法中调用的test1()中的参数,进行测试
			@Test
			public void test(){
				test1("B",4);
				
			} 
	
			//发货分析的方法
			public static void test1(String type,Integer number){
				
				//定义整型变量,后面要用到
				int x=0;
				
				//创建仓库
				Warehouse w1 = new Warehouse();
				Warehouse w2 = new Warehouse();
				Warehouse w3 = new Warehouse();
				Warehouse wx = new Warehouse();
				
				//设置权重
				w1.setWeight(3);
				w2.setWeight(1);
				w3.setWeight(2);
				
				//仓库w1,w2,w3的单种产品的数量
				w1.setAmount(0);
				w2.setAmount(0);
				w3.setAmount(0);
				
				//创建仓库对应的商品集合
				List<Product> list1 =new ArrayList<Product>();
				w1.setList(list1);
				List<Product> list2 =new ArrayList<Product>();
				w2.setList(list2);
				List<Product> list3 =new ArrayList<Product>();
				w3.setList(list3);
				
				//添加商品
				list1.add(new Product("A","A1"));
				list1.add(new Product("B","B1"));
				list1.add(new Product("B","B2"));
				list1.add(new Product("C","C1"));
				list1.add(new Product("C","C2"));
				
				list2.add(new Product("A","A2"));
				list2.add(new Product("A","A3"));
				list2.add(new Product("B","B3"));
				list2.add(new Product("C","C3"));
				list2.add(new Product("C","C4"));
				
				list3.add(new Product("A","A4"));
				list3.add(new Product("B","B4"));
				list3.add(new Product("B","B5"));
				list3.add(new Product("B","B6"));
				list3.add(new Product("C","C5"));
				
				//将仓库w1,w2,w3按权重排序
				Warehouse[] ws = {w1,w2,w3};
				for(int i=0;i<ws.length;i++){
					for(int j=i+1;j<ws.length;j++){
						if(ws[i].getWeight()<ws[j].getWeight()){
							wx=ws[i];
							ws[i]=ws[j];
							ws[j]=wx;
						}
					}
				}
				
				//配送方案的逻辑运算
				for(int i=0;i<ws[0].getList().size();i++){
					if(ws[0].getList().get(i).getCt()==type){
						x++;
					}	
				}
				ws[0].setAmount(x);
				x=0;
				if(ws[0].getAmount()>=number){
					System.out.print("配送方案为:从仓库w1取"+type+"产品"+number+"件;");
				}else{
					System.out.print("配送方案为:从仓库w1取"+type+"产品"+ws[0].getAmount()+"件;");
					for(int i=0;i<ws[1].getList().size();i++){
						if(ws[1].getList().get(i).getCt()==type){
							x++;
						}
					}
					ws[1].setAmount(x);
					x=0;
					if(ws[1].getAmount()>=(number-ws[0].getAmount())){
						System.out.print("从仓库w3取"+type+"产品"+(number-ws[0].getAmount())+"件;");
						
					}else{
						System.out.print("从仓库w3取"+type+"产品"+ws[1].getAmount()+"件;");
						for(int i=0;i<ws[2].getList().size();i++){
							if(ws[2].getList().get(i).getCt()==type){
								x++;
							}
						}
						ws[2].setAmount(x);
						x=0;
						if(ws[2].getAmount()>=(number-ws[1].getAmount()-ws[0].getAmount())){
							System.out.println("从仓库w2取"+type+"产品"+(number-ws[1].getAmount()-ws[0].getAmount())+"件;");
							
						}else{
							System.out.println("w2的"+type+"产品库存不够,配送失败!!!");
						}
					}
				}
			}
	
}

