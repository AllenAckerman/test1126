package com.xjbd.test1126.entity;

import java.util.List;

import com.xjbd.test1126.entity.Product;

//仓库类
public class Warehouse {
	
	private int weight;//总体情况下的发货顺序的权重
	private int amount;//仓库中一种产品的总量
	private List<Product> list;//仓库中的产品集合

	
	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public List<Product> getList() {
		return list;
	}

	public void setList(List<Product> list) {
		this.list = list;
	}
}
