package com.xjbd.test1126.entity;

//产品类
public class Product {
	
	private String ct;//产品种类
	private String name;//名字用来区分同种产品,无重要意义
	
	public Product(String ct, String name) {
		//super();
		this.ct = ct;
		this.name = name;
	}
	public String getCt() {
		return ct;
	}
	public void setCt(String ct) {
		this.ct = ct;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}

